let prompt = document.querySelector(".prompt");
let chatbox = document.querySelector(".chat-container")
let uploadbtn = document.querySelector(".upload")



const Api_URl = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=AIzaSyCbscH1y9VK8Uql18iv_GWd25l9ylwbED4"

let user = {
    data: null,
}

async function generateResponse(aichatbox) {


    let text = aichatbox.querySelector(".ai-chat-area")
    let RequestOption = {
        method: "post",
        header: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            "contents": [
                {
                    "parts": [{ "text": user.data }]
                }]
        })

    }


    try {

        let response = await fetch(Api_URl, RequestOption)
        let data = await  response.json()
       let apiresponse = data.candidates[0].content.parts[0].text.replace(/\*\*(.*?)\*\*/g, "$1").trim()
        text.innerHTML=apiresponse;
    }

    catch(error){
        console.log(error)
    }

    finally{
        chatbox.scrollTo({top:chatbox.scrollHeight , behavior:"smooth"})

    }


    
}



function createchatbox(html, classses) {
    let div = document.createElement("div")
    div.innerHTML = html;
    div.classList.add(classses);
    return div;
}

function handleresponse(message) {
    user.data = message;
    let html = `<img src="User.png" alt="Not Found" width="50px" class="image1">
                <div class="user-chat-area">
                ${user.data}
                </div>`

    prompt.value = " ";
    let makechatbox = createchatbox(html, "user-chat-box")
    chatbox.append(makechatbox);

    chatbox.scrollTo({top:chatbox.scrollHeight , behavior:"smooth"})


    setTimeout(() => {
        let html = ` <img src="robot.png" alt="Not Found" width="50px" class="image2">
                <div class="ai-chat-area">
                    
                    <img src="loading.webp" alt="" class="load" width="50px">
                </div>`

        let aichatbox = createchatbox(html, "ai-chat-box");
        chatbox.append(aichatbox)
        generateResponse(aichatbox)

    }, 600);





}

uploadbtn.addEventListener("click",()=>{
    handleresponse(prompt.value);


})

prompt.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
        handleresponse(prompt.value);



    }
})
